public enum LanguageType {
    QA, BACKEND, FRONTEND
}
